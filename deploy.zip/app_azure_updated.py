import os
import streamlit as st
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from openai import AzureOpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set page configuration
st.set_page_config(page_title="Medical Gynecology Assistant", layout="wide")

# App title
st.title("Medical Gynecology Assistant")

# Initialize session state for conversation history
if "messages" not in st.session_state:
    st.session_state.messages = []

@st.cache_resource
def load_retriever():
    """Load FAISS index or create if not exists"""
    if os.path.exists("faiss_index"):
        # Load existing index
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'}
        )
        vector_store = FAISS.load_local("faiss_index", embeddings)
        st.sidebar.write("Loaded existing FAISS index")
    else:
        st.sidebar.write("No existing index found. Please run preprocess.py first.")
        st.stop()
    
    # Create retriever
    retriever = vector_store.as_retriever(search_kwargs={"k": 5})
    return retriever

@st.cache_resource
def create_azure_openai_client():
    """Create Azure OpenAI client"""
    try:
        endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        api_key = os.environ.get("AZURE_OPENAI_KEY")
        api_version = "2023-05-15"  # Using an older version for compatibility
        
        # Simpler initialization for older OpenAI versions
        client = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version=api_version
        )
        return client
    except Exception as e:
        st.error(f"Error creating Azure OpenAI client: {str(e)}")
        return None

def call_azure_openai(prompt):
    """Call Azure OpenAI service using the official client"""
    try:
        client = create_azure_openai_client()
        if not client:
            return "Azure OpenAI client could not be created. Check your credentials."
        
        deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-35-turbo")
        
        response = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": "You are a medical assistant specializing in gynecology. Provide clear, accurate information based on medical literature. Include relevant details and maintain a professional tone."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=800,
            temperature=0.3,
            model=deployment
        )
        
        return response.choices[0].message.content
    
    except Exception as e:
        return f"Error: {str(e)}"

def generate_answer(question, docs):
    """Generate an answer based on retrieved documents"""
    # Extract content and citations
    contexts = []
    citations = []
    
    for i, doc in enumerate(docs):
        source = os.path.basename(doc.metadata.get('source', 'unknown'))
        page = doc.metadata.get('page', 'unknown')
        citation = f"[{i+1}] {source}, page {page}"
        
        contexts.append(doc.page_content)
        citations.append(citation)
    
    # Combine contexts
    full_context = "\n\n".join([f"Document {i+1} (from {os.path.basename(doc.metadata.get('source', 'unknown'))}, page {doc.metadata.get('page', 'unknown')}):\n{doc.page_content}" for i, doc in enumerate(docs)])
    
    # Create prompt for Azure OpenAI
    prompt = f"""
    Based on the following medical literature, answer this question: {question}
    
    Medical literature:
    {full_context}
    
    Provide a detailed and accurate answer based only on the information in the medical literature. 
    Include citations like [1], [2], etc. when referencing specific information from the documents.
    """
    
    # Generate summary using Azure OpenAI
    summary = call_azure_openai(prompt)
    
    # Format answer with citations
    answer = f"**Question:** {question}\n\n**Answer:** {summary}\n\n**Sources:**\n"
    for citation in citations:
        answer += f"- {citation}\n"
    
    return answer

# Sidebar information
with st.sidebar:
    st.header("About")
    st.write("This application uses RAG to answer questions about gynecology based on medical textbooks.")
    
    # Load retriever on app startup
    with st.spinner("Loading medical knowledge base..."):
        retriever = load_retriever()
    
    st.success("Medical knowledge base loaded!")
    
    # Azure OpenAI status
    if os.environ.get("AZURE_OPENAI_ENDPOINT") and os.environ.get("AZURE_OPENAI_KEY"):
        st.success("Azure OpenAI connected")
    else:
        st.warning("Azure OpenAI not configured - set environment variables")

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("Ask a question about gynecology"):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.write(prompt)
    
    # Generate response
    with st.chat_message("assistant"):
        with st.spinner("Generating answer..."):
            # Get relevant documents
            docs = retriever.get_relevant_documents(prompt)
            
            # Generate answer
            response = generate_answer(prompt, docs)
            
        st.markdown(response)
    
    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response})