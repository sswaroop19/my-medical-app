#!/bin/bash

# Make sure the FAISS index directory exists
mkdir -p faiss_index

# Start the Streamlit app
streamlit run app_azure_updated.py --server.port 8000 --server.address 0.0.0.0